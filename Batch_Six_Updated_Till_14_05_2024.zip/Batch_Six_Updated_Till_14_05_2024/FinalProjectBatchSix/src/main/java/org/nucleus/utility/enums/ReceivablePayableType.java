package org.nucleus.utility.enums;

public enum ReceivablePayableType {
    RECEIVABLE
    ,
    PAYABLE
}
