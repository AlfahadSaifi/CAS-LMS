package org.nucleus.utility.enums;

public enum RecoveryType {
    INSTALLMENT , NONINSTALLMENT
}
