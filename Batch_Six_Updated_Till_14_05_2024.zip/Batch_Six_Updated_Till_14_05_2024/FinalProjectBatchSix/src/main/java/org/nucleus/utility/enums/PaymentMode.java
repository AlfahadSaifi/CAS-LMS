package org.nucleus.utility.enums;

public enum PaymentMode {
    CASH,DRAFT
}
