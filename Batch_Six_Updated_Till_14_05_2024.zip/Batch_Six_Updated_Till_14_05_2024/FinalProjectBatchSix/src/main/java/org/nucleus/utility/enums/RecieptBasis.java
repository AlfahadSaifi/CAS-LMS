//package org.nucleus.utility.enums;
//
//public enum RecieptBasis {
//    SINGLE_ACCOUNT
//}
