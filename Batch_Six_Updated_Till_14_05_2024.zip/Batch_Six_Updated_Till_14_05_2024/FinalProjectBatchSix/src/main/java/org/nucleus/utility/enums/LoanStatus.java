package org.nucleus.utility.enums;

public enum LoanStatus {
    PENDING, APPROVED, REJECTED, ACTIVE, CLOSED, INACTIVE
}
