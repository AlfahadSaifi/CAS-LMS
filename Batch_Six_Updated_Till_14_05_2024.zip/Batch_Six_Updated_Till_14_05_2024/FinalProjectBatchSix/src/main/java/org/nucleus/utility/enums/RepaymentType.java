package org.nucleus.utility.enums;

public enum RepaymentType {
    INTEREST_ONLY , PRINCIPAL_AND_INTEREST
}
