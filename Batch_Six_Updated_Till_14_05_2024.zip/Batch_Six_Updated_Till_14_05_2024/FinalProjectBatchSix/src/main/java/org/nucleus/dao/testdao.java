package org.nucleus.dao;

public class testdao {
}
